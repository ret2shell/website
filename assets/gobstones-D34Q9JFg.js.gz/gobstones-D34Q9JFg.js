import{g as o}from"./_commonjsHelpers-Cpj98o6Y.js";function F(p,e){for(var n=0;n<e.length;n++){const _=e[n];if(typeof _!="string"&&!Array.isArray(_)){for(const T in _)if(T!=="default"&&!(T in p)){const t=Object.getOwnPropertyDescriptor(_,T);t&&Object.defineProperty(p,T,t.get?t:{enumerable:!0,get:()=>_[T]})}}}return Object.freeze(Object.defineProperty(p,Symbol.toStringTag,{value:"Module"}))}var K={exports:{}};(function(p,e){ace.define("ace/snippets/gobstones.snippets",["require","exports","module"],function(n,_,T){T.exports=`# scope: gobstones

# program
snippet program
	program {
		\${1:// cuerpo...}
	}

# interactive program
snippet interactive program
	interactive program {
		\${1:INIT} -> { \${2:// cuerpo...} }
		\${3:TIMEOUT(\${4:5000}) -> { \${5:// cuerpo...} }
		\${6:K_ENTER} -> { \${7:// cuerpo...} }
		_ -> {}
	}

# procedure
snippet procedure
	procedure \${1:Nombre}(\${2:parametros}) {
		\${3:// cuerpo...}
	}

# function
snippet function
	function \${1:nombre}(\${2:parametros}) {
		return (\${3:expresión..})
	}

# return
snippet return
	return (\${1:expresión...})

# type
snippet type
	type \${1:Nombre}

# is variant
snippet is variant
	is variant {
		case \${1:NombreDelValor1} {}
		case \${2:NombreDelValor2} {}
		case \${3:NombreDelValor3} {}
		case \${4:NombreDelValor4} {}
	}

# is record
snippet is record
	is record {
		field \${1:campo1} // \${2:Tipo}
		field \${3:campo2} // \${4:Tipo}
		field \${5:campo3} // \${6:Tipo}
		field \${7:campo4} // \${8:Tipo}
	}

# type _ is variant
snippet type _ is variant
	type \${1:Nombre} is variant {
		case \${2:NombreDelValor1} {}
		case \${3:NombreDelValor2} {}
		case \${4:NombreDelValor3} {}
		case \${5:NombreDelValor4} {}
	}

# type _ is record
snippet type _ is record
	type \${1:Nombre} is record {
		field \${2:campo1} // \${3:Tipo}
		field \${4:campo2} // \${5:Tipo}
		field \${6:campo3} // \${7:Tipo}
		field \${8:campo4} // \${9:Tipo}
	}

# repeat
snippet repeat
	repeat \${1:cantidad} {
		\${2:// cuerpo...}
	}

# foreach
snippet foreach
	foreach \${1:índice} in \${2:lista} {
		\${3:// cuerpo...}
	}

# while
snippet while
	while (\${1?:condición}) {
		\${2:// cuerpo...}
	}

# if
snippet if
	if (\${1?:condición}) {
		\${2:// cuerpo...}
	}

# elseif
snippet elseif
	elseif (\${1?:condición}) {
		\${2:// cuerpo...}
	}

# else
snippet else
	else {
		\${1:// cuerpo...}
	}

# if (con else)
snippet if (con else)
	if (\${1:condición}) {
		\${2:// cuerpo...}
	} else {
		\${3:// cuerpo....}
	}

# if (con elseif)
snippet if (con elseif)
	if (\${1:condición}) {
		\${2:// cuerpo...}
	} elseif (\${3:condición}) {
		\${4:// cuerpo...}
	}

# if (con elseif y else)
snippet if (con elseif y else)
	if (\${1:condición}) {
		\${2:// cuerpo...}
	} elseif (\${3:condición}) {
		\${4:// cuerpo...}
	} else {
		\${5:// cuerpo....}
	}

# if (con 3 elseif)
snippet if (con 3 elseif)
	if (\${1:condición}) {
		\${2:// cuerpo...}
	} elseif (\${3:condición}) {
		\${4:// cuerpo...}
	} elseif (\${5:condición}) {
		\${6:// cuerpo...}
	} elseif (\${7:condición}) {
		\${8:// cuerpo...}
	}

# choose (2 valores)
snippet choose (2 valores)
	choose
		\${1:Valor1} when (\${2:condición})
		\${3:Valor2} otherwise

# choose (2 valores y boom)
snippet choose (2 valores y boom)
	choose
		\${1:Valor1} when (\${2:condición})
		\${3:Valor2} when (\${4:condición})
		\${5:Valor3} when (\${6:condición})
		\${7:Valor4} when (\${8:condición})
		boom("\${9:No es un valor válido}") otherwise

# matching (4 valores)
snippet matching (4 valores)
	matching (\${1:variable}) select
		\${2:Valor1} on \${3:opción1}
		\${4:Valor2} on \${5:opción2}
		\${6:Valor3} on \${7:opción3}
		\${8:Valor4} on \${9:opción4}
		boom("\${10:No es un valor válido}") otherwise

# select (4 casos)
snippet select (4 casos)
	select
		\${1:Valor1} on (\${2:opción1})
		\${3:Valor2} on (\${4:opción2})
		\${5:Valor3} on (\${6:opción3})
		\${7:Valor4} on (\${8:opción4})
		boom("\${9:No es un valor válido}") otherwise

# switch
snippet switch
	switch (\${1:variable}) {
		\${2:Valor1} -> {\${3:// cuerpo...}}
		\${4:Valor2} -> {\${5:// cuerpo...}}
		\${6:Valor3} -> {\${7:// cuerpo...}}
		\${8:Valor4} -> {\${9:// cuerpo...}}
		_ -> {\${10:// cuerpo...}}
	}

# Poner
snippet Poner
	Poner(\${1:color})

# Sacar
snippet Sacar
	Sacar(\${1:color})

# Mover
snippet Mover
	Mover(\${1:dirección})

# IrAlBorde
snippet IrAlBorde
	IrAlBorde(\${1:dirección})

# VaciarTablero
snippet VaciarTablero
	VaciarTablero()

# BOOM
snippet BOOM
	BOOM("\${1:Mensaje de error}")

# hayBolitas
snippet hayBolitas
	hayBolitas(\${1:color})

# nroBolitas
snippet nroBolitas
	nroBolitas(\${1:color})

# puedeMover
snippet puedeMover
	puedeMover(\${1:dirección})

# siguiente
snippet siguiente
	siguiente(\${1:color|dirección})

# previo
snippet previo
	previo(\${1:color|dirección})

# opuesto
snippet opuesto
	opuesto(\${1:dirección})

# minDir
snippet minDir
	minDir()

# maxDir
snippet maxDir
	maxDir()

# minColor
snippet minColor
	minDir()

# maxColor
snippet maxColor
	maxDir()

# minBool
snippet minBool
	minBool()

# maxBool
snippet maxBool
	maxBool()

# primero
snippet primero
	primero(\${1:lista})

# sinElPrimero
snippet sinElPrimero
	sinElPrimero(\${1:lista})

# esVacía
snippet esVacía
	esVacía(\${1:lista})

# boom
snippet boom
	boom("\${1:Mensaje de error}")

# Azul
snippet Azul
	Azul

# Negro
snippet Negro
	Negro

# Rojo
snippet Rojo
	Rojo

# Verde
snippet Verde
	Verde

# Norte
snippet Norte
	Norte

# Este
snippet Este
	Este

# Sur
snippet Sur
	Sur

# Oeste
snippet Oeste
	Oeste

# True
snippet True
	True

# False
snippet False
	False

# INIT
snippet INIT
	INIT -> {$1:// cuerpo...}

# TIMEOUT
snippet TIMEOUT
	TIMEOUT(\${1:5000}) -> {$2:// cuerpo...}

# K_A
snippet K_A
	K_A -> { \${1://cuerpo...} }
# K_CTRL_A
snippet K_CTRL_A
	K_CTRL_A -> { \${1://cuerpo...} }
# K_ALT_A
snippet K_ALT_A
	K_ALT_A -> { \${1://cuerpo...} }
# K_SHIFT_A
snippet K_SHIFT_A
	K_SHIFT_A -> { \${1://cuerpo...} }
# K_CTRL_ALT_A
snippet K_CTRL_ALT_A
	K_CTRL_ALT_A -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_A
snippet K_CTRL_SHIFT_A
	K_CTRL_SHIFT_A -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_A
snippet K_CTRL_ALT_SHIFT_A
	K_CTRL_ALT_SHIFT_A -> { \${1://cuerpo...} }

# K_B
snippet K_B
	K_B -> { \${1://cuerpo...} }
# K_CTRL_B
snippet K_CTRL_B
	K_CTRL_B -> { \${1://cuerpo...} }
# K_ALT_B
snippet K_ALT_B
	K_ALT_B -> { \${1://cuerpo...} }
# K_SHIFT_B
snippet K_SHIFT_B
	K_SHIFT_B -> { \${1://cuerpo...} }
# K_CTRL_ALT_B
snippet K_CTRL_ALT_B
	K_CTRL_ALT_B -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_B
snippet K_CTRL_SHIFT_B
	K_CTRL_SHIFT_B -> { \${1://cuerpo...} }
# K_ALT_SHIFT_C
snippet K_ALT_SHIFT_C
	K_ALT_SHIFT_C -> { \${1://cuerpo...} }
# K_CTRL_BLT_SHIFT_B
snippet K_CTRL_BLT_SHIFT_B
	K_CTRL_ALT_SHIFT_B -> { \${1://cuerpo...} }

# K_C
snippet K_C
	K_C -> { \${1://cuerpo...} }
# K_CTRL_C
snippet K_CTRL_C
	K_CTRL_C -> { \${1://cuerpo...} }
# K_ALT_C
snippet K_ALT_C
	K_ALT_C -> { \${1://cuerpo...} }
# K_SHIFT_C
snippet K_SHIFT_C
	K_SHIFT_C -> { \${1://cuerpo...} }
# K_CTRL_ALT_C
snippet K_CTRL_ALT_C
	K_CTRL_ALT_C -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_C
snippet K_CTRL_SHIFT_C
	K_CTRL_SHIFT_C -> { \${1://cuerpo...} }
# K_ALT_SHIFT_C
snippet K_ALT_SHIFT_C
	K_ALT_SHIFT_C -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_C
snippet K_CTRL_ALT_SHIFT_C
	K_CTRL_ALT_SHIFT_C -> { \${1://cuerpo...} }

# K_D
snippet K_D
	K_D -> { \${1://cuerpo...} }
# K_CTRL_D
snippet K_CTRL_D
	K_CTRL_D -> { \${1://cuerpo...} }
# K_ALT_D
snippet K_ALT_D
	K_DLT_D -> { \${1://cuerpo...} }
# K_SHIFT_D
snippet K_SHIFT_D
	K_SHIFT_D -> { \${1://cuerpo...} }
# K_CTRL_ALT_D
snippet K_CTRL_ALT_D
	K_CTRL_DLT_D -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_D
snippet K_CTRL_SHIFT_D
	K_CTRL_SHIFT_D -> { \${1://cuerpo...} }
# K_ALT_SHIFT_D
snippet K_ALT_SHIFT_D
	K_ALT_SHIFT_D -> { \${1://cuerpo...} }
# K_CTRL_DLT_SHIFT_D
snippet K_CTRL_DLT_SHIFT_D
	K_CTRL_ALT_SHIFT_D -> { \${1://cuerpo...} }

# K_E
snippet K_E
	K_E -> { \${1://cuerpo...} }
# K_CTRL_E
snippet K_CTRL_E
	K_CTRL_E -> { \${1://cuerpo...} }
# K_ALT_E
snippet K_ALT_E
	K_ALT_E -> { \${1://cuerpo...} }
# K_SHIFT_E
snippet K_SHIFT_E
	K_SHIFT_E -> { \${1://cuerpo...} }
# K_CTRL_ALT_E
snippet K_CTRL_ALT_E
	K_CTRL_ALT_E -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_E
snippet K_CTRL_SHIFT_E
	K_CTRL_SHIFT_E -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_E
snippet K_CTRL_ALT_SHIFT_E
	K_CTRL_ALT_SHIFT_E -> { \${1://cuerpo...} }

# K_F
snippet K_F
	K_F -> { \${1://cuerpo...} }
# K_CTRL_F
snippet K_CTRL_F
	K_CTRL_F -> { \${1://cuerpo...} }
# K_ALT_F
snippet K_ALT_F
	K_ALT_F -> { \${1://cuerpo...} }
# K_SHIFT_F
snippet K_SHIFT_F
	K_SHIFT_F -> { \${1://cuerpo...} }
# K_CTRL_ALT_F
snippet K_CTRL_ALT_F
	K_CTRL_ALT_F -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F
snippet K_CTRL_SHIFT_F
	K_CTRL_SHIFT_F -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F
snippet K_CTRL_ALT_SHIFT_F
	K_CTRL_ALT_SHIFT_F -> { \${1://cuerpo...} }

# K_G
snippet K_G
	K_G -> { \${1://cuerpo...} }
# K_CTRL_G
snippet K_CTRL_G
	K_CTRL_G -> { \${1://cuerpo...} }
# K_ALT_G
snippet K_ALT_G
	K_ALT_G -> { \${1://cuerpo...} }
# K_SHIFT_G
snippet K_SHIFT_G
	K_SHIFT_G -> { \${1://cuerpo...} }
# K_CTRL_ALT_G
snippet K_CTRL_ALT_G
	K_CTRL_ALT_G -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_G
snippet K_CTRL_SHIFT_G
	K_CTRL_SHIFT_G -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_G
snippet K_CTRL_ALT_SHIFT_G
	K_CTRL_ALT_SHIFT_G -> { \${1://cuerpo...} }

# K_H
snippet K_H
	K_H -> { \${1://cuerpo...} }
# K_CTRL_H
snippet K_CTRL_H
	K_CTRL_H -> { \${1://cuerpo...} }
# K_ALT_H
snippet K_ALT_H
	K_ALT_H -> { \${1://cuerpo...} }
# K_SHIFT_H
snippet K_SHIFT_H
	K_SHIFT_H -> { \${1://cuerpo...} }
# K_CTRL_ALT_H
snippet K_CTRL_ALT_H
	K_CTRL_ALT_H -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_H
snippet K_CTRL_SHIFT_H
	K_CTRL_SHIFT_H -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_H
snippet K_CTRL_ALT_SHIFT_H
	K_CTRL_ALT_SHIFT_H -> { \${1://cuerpo...} }

# K_I
snippet K_I
	K_I -> { \${1://cuerpo...} }
# K_CTRL_I
snippet K_CTRL_I
	K_CTRL_I -> { \${1://cuerpo...} }
# K_ALT_I
snippet K_ALT_I
	K_ALT_I -> { \${1://cuerpo...} }
# K_SHIFT_I
snippet K_SHIFT_I
	K_SHIFT_I -> { \${1://cuerpo...} }
# K_CTRL_ALT_I
snippet K_CTRL_ALT_I
	K_CTRL_ALT_I -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_I
snippet K_CTRL_SHIFT_I
	K_CTRL_SHIFT_I -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_I
snippet K_CTRL_ALT_SHIFT_I
	K_CTRL_ALT_SHIFT_I -> { \${1://cuerpo...} }

# K_J
snippet K_J
	K_J -> { \${1://cuerpo...} }
# K_CTRL_J
snippet K_CTRL_J
	K_CTRL_J -> { \${1://cuerpo...} }
# K_ALT_J
snippet K_ALT_J
	K_ALT_J -> { \${1://cuerpo...} }
# K_SHIFT_J
snippet K_SHIFT_J
	K_SHIFT_J -> { \${1://cuerpo...} }
# K_CTRL_ALT_J
snippet K_CTRL_ALT_J
	K_CTRL_ALT_J -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_J
snippet K_CTRL_SHIFT_J
	K_CTRL_SHIFT_J -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_J
snippet K_CTRL_ALT_SHIFT_J
	K_CTRL_ALT_SHIFT_J -> { \${1://cuerpo...} }

# K_K
snippet K_K
	K_K -> { \${1://cuerpo...} }
# K_CTRL_K
snippet K_CTRL_K
	K_CTRL_K -> { \${1://cuerpo...} }
# K_ALT_K
snippet K_ALT_K
	K_ALT_K -> { \${1://cuerpo...} }
# K_SHIFT_K
snippet K_SHIFT_K
	K_SHIFT_K -> { \${1://cuerpo...} }
# K_CTRL_ALT_K
snippet K_CTRL_ALT_K
	K_CTRL_ALT_K -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_K
snippet K_CTRL_SHIFT_K
	K_CTRL_SHIFT_K -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_K
snippet K_CTRL_ALT_SHIFT_K
	K_CTRL_ALT_SHIFT_K -> { \${1://cuerpo...} }

# K_L
snippet K_L
	K_L -> { \${1://cuerpo...} }
# K_CTRL_L
snippet K_CTRL_L
	K_CTRL_L -> { \${1://cuerpo...} }
# K_ALT_L
snippet K_ALT_L
	K_ALT_L -> { \${1://cuerpo...} }
# K_SHIFT_L
snippet K_SHIFT_L
	K_SHIFT_L -> { \${1://cuerpo...} }
# K_CTRL_ALT_L
snippet K_CTRL_ALT_L
	K_CTRL_ALT_L -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_L
snippet K_CTRL_SHIFT_L
	K_CTRL_SHIFT_L -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_L
snippet K_CTRL_ALT_SHIFT_L
	K_CTRL_ALT_SHIFT_L -> { \${1://cuerpo...} }

# K_M
snippet K_M
	K_M -> { \${1://cuerpo...} }
# K_CTRL_M
snippet K_CTRL_M
	K_CTRL_M -> { \${1://cuerpo...} }
# K_ALT_M
snippet K_ALT_M
	K_ALT_M -> { \${1://cuerpo...} }
# K_SHIFT_M
snippet K_SHIFT_M
	K_SHIFT_M -> { \${1://cuerpo...} }
# K_CTRL_ALT_M
snippet K_CTRL_ALT_M
	K_CTRL_ALT_M -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_M
snippet K_CTRL_SHIFT_M
	K_CTRL_SHIFT_M -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_M
snippet K_CTRL_ALT_SHIFT_M
	K_CTRL_ALT_SHIFT_M -> { \${1://cuerpo...} }

# K_N
snippet K_N
	K_N -> { \${1://cuerpo...} }
# K_CTRL_N
snippet K_CTRL_N
	K_CTRL_N -> { \${1://cuerpo...} }
# K_ALT_N
snippet K_ALT_N
	K_ALT_N -> { \${1://cuerpo...} }
# K_SHIFT_N
snippet K_SHIFT_N
	K_SHIFT_N -> { \${1://cuerpo...} }
# K_CTRL_ALT_N
snippet K_CTRL_ALT_N
	K_CTRL_ALT_N -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_N
snippet K_CTRL_SHIFT_N
	K_CTRL_SHIFT_N -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_N
snippet K_CTRL_ALT_SHIFT_N
	K_CTRL_ALT_SHIFT_N -> { \${1://cuerpo...} }

# K_Ñ
snippet K_Ñ
	K_Ñ -> { \${1://cuerpo...} }
# K_CTRL_Ñ
snippet K_CTRL_Ñ
	K_CTRL_Ñ -> { \${1://cuerpo...} }
# K_ALT_Ñ
snippet K_ALT_Ñ
	K_ALT_Ñ -> { \${1://cuerpo...} }
# K_SHIFT_Ñ
snippet K_SHIFT_Ñ
	K_SHIFT_Ñ -> { \${1://cuerpo...} }
# K_CTRL_ALT_Ñ
snippet K_CTRL_ALT_Ñ
	K_CTRL_ALT_Ñ -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_Ñ
snippet K_CTRL_SHIFT_Ñ
	K_CTRL_SHIFT_Ñ -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_Ñ
snippet K_CTRL_ALT_SHIFT_Ñ
	K_CTRL_ALT_SHIFT_Ñ -> { \${1://cuerpo...} }

# K_O
snippet K_O
	K_O -> { \${1://cuerpo...} }
# K_CTRL_O
snippet K_CTRL_O
	K_CTRL_O -> { \${1://cuerpo...} }
# K_ALT_O
snippet K_ALT_O
	K_ALT_O -> { \${1://cuerpo...} }
# K_SHIFT_O
snippet K_SHIFT_O
	K_SHIFT_O -> { \${1://cuerpo...} }
# K_CTRL_ALT_O
snippet K_CTRL_ALT_O
	K_CTRL_ALT_O -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_O
snippet K_CTRL_SHIFT_O
	K_CTRL_SHIFT_O -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_O
snippet K_CTRL_ALT_SHIFT_O
	K_CTRL_ALT_SHIFT_O -> { \${1://cuerpo...} }

# K_P
snippet K_P
	K_P -> { \${1://cuerpo...} }
# K_CTRL_P
snippet K_CTRL_P
	K_CTRL_P -> { \${1://cuerpo...} }
# K_ALT_P
snippet K_ALT_P
	K_ALT_P -> { \${1://cuerpo...} }
# K_SHIFT_P
snippet K_SHIFT_P
	K_SHIFT_P -> { \${1://cuerpo...} }
# K_CTRL_ALT_P
snippet K_CTRL_ALT_P
	K_CTRL_ALT_P -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_P
snippet K_CTRL_SHIFT_P
	K_CTRL_SHIFT_P -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_P
snippet K_CTRL_ALT_SHIFT_P
	K_CTRL_ALT_SHIFT_P -> { \${1://cuerpo...} }

# K_Q
snippet K_Q
	K_Q -> { \${1://cuerpo...} }
# K_CTRL_Q
snippet K_CTRL_Q
	K_CTRL_Q -> { \${1://cuerpo...} }
# K_ALT_Q
snippet K_ALT_Q
	K_ALT_Q -> { \${1://cuerpo...} }
# K_SHIFT_Q
snippet K_SHIFT_Q
	K_SHIFT_Q -> { \${1://cuerpo...} }
# K_CTRL_ALT_Q
snippet K_CTRL_ALT_Q
	K_CTRL_ALT_Q -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_Q
snippet K_CTRL_SHIFT_Q
	K_CTRL_SHIFT_Q -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_Q
snippet K_CTRL_ALT_SHIFT_Q
	K_CTRL_ALT_SHIFT_Q -> { \${1://cuerpo...} }

# K_R
snippet K_R
	K_R -> { \${1://cuerpo...} }
# K_CTRL_R
snippet K_CTRL_R
	K_CTRL_R -> { \${1://cuerpo...} }
# K_ALT_R
snippet K_ALT_R
	K_ALT_R -> { \${1://cuerpo...} }
# K_SHIFT_R
snippet K_SHIFT_R
	K_SHIFT_R -> { \${1://cuerpo...} }
# K_CTRL_ALT_R
snippet K_CTRL_ALT_R
	K_CTRL_ALT_R -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_R
snippet K_CTRL_SHIFT_R
	K_CTRL_SHIFT_R -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_R
snippet K_CTRL_ALT_SHIFT_R
	K_CTRL_ALT_SHIFT_R -> { \${1://cuerpo...} }

# K_S
snippet K_S
	K_S -> { \${1://cuerpo...} }
# K_CTRL_S
snippet K_CTRL_S
	K_CTRL_S -> { \${1://cuerpo...} }
# K_ALT_S
snippet K_ALT_S
	K_ALT_S -> { \${1://cuerpo...} }
# K_SHIFT_S
snippet K_SHIFT_S
	K_SHIFT_S -> { \${1://cuerpo...} }
# K_CTRL_ALT_S
snippet K_CTRL_ALT_S
	K_CTRL_ALT_S -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_S
snippet K_CTRL_SHIFT_S
	K_CTRL_SHIFT_S -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_S
snippet K_CTRL_ALT_SHIFT_S
	K_CTRL_ALT_SHIFT_S -> { \${1://cuerpo...} }

# K_T
snippet K_T
	K_T -> { \${1://cuerpo...} }
# K_CTRL_T
snippet K_CTRL_T
	K_CTRL_T -> { \${1://cuerpo...} }
# K_ALT_T
snippet K_ALT_T
	K_ALT_T -> { \${1://cuerpo...} }
# K_SHIFT_T
snippet K_SHIFT_T
	K_SHIFT_T -> { \${1://cuerpo...} }
# K_CTRL_ALT_T
snippet K_CTRL_ALT_T
	K_CTRL_ALT_T -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_T
snippet K_CTRL_SHIFT_T
	K_CTRL_SHIFT_T -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_T
snippet K_CTRL_ALT_SHIFT_T
	K_CTRL_ALT_SHIFT_T -> { \${1://cuerpo...} }

# K_U
snippet K_U
	K_U -> { \${1://cuerpo...} }
# K_CTRL_U
snippet K_CTRL_U
	K_CTRL_U -> { \${1://cuerpo...} }
# K_ALT_U
snippet K_ALT_U
	K_ALT_U -> { \${1://cuerpo...} }
# K_SHIFT_U
snippet K_SHIFT_U
	K_SHIFT_U -> { \${1://cuerpo...} }
# K_CTRL_ALT_U
snippet K_CTRL_ALT_U
	K_CTRL_ALT_U -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_U
snippet K_CTRL_SHIFT_U
	K_CTRL_SHIFT_U -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_U
snippet K_CTRL_ALT_SHIFT_U
	K_CTRL_ALT_SHIFT_U -> { \${1://cuerpo...} }

# K_V
snippet K_V
	K_V -> { \${1://cuerpo...} }
# K_CTRL_V
snippet K_CTRL_V
	K_CTRL_V -> { \${1://cuerpo...} }
# K_ALT_V
snippet K_ALT_V
	K_ALT_V -> { \${1://cuerpo...} }
# K_SHIFT_V
snippet K_SHIFT_V
	K_SHIFT_V -> { \${1://cuerpo...} }
# K_CTRL_ALT_V
snippet K_CTRL_ALT_V
	K_CTRL_ALT_V -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_V
snippet K_CTRL_SHIFT_V
	K_CTRL_SHIFT_V -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_V
snippet K_CTRL_ALT_SHIFT_V
	K_CTRL_ALT_SHIFT_V -> { \${1://cuerpo...} }

# K_W
snippet K_W
	K_W -> { \${1://cuerpo...} }
# K_CTRL_W
snippet K_CTRL_W
	K_CTRL_W -> { \${1://cuerpo...} }
# K_ALT_W
snippet K_ALT_W
	K_ALT_W -> { \${1://cuerpo...} }
# K_SHIFT_W
snippet K_SHIFT_W
	K_SHIFT_W -> { \${1://cuerpo...} }
# K_CTRL_ALT_W
snippet K_CTRL_ALT_W
	K_CTRL_ALT_W -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_W
snippet K_CTRL_SHIFT_W
	K_CTRL_SHIFT_W -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_W
snippet K_CTRL_ALT_SHIFT_W
	K_CTRL_ALT_SHIFT_W -> { \${1://cuerpo...} }

# K_X
snippet K_X
	K_X -> { \${1://cuerpo...} }
# K_CTRL_X
snippet K_CTRL_X
	K_CTRL_X -> { \${1://cuerpo...} }
# K_ALT_X
snippet K_ALT_X
	K_ALT_X -> { \${1://cuerpo...} }
# K_SHIFT_X
snippet K_SHIFT_X
	K_SHIFT_X -> { \${1://cuerpo...} }
# K_CTRL_ALT_X
snippet K_CTRL_ALT_X
	K_CTRL_ALT_X -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_X
snippet K_CTRL_SHIFT_X
	K_CTRL_SHIFT_X -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_X
snippet K_CTRL_ALT_SHIFT_X
	K_CTRL_ALT_SHIFT_X -> { \${1://cuerpo...} }

# K_Y
snippet K_Y
	K_Y -> { \${1://cuerpo...} }
# K_CTRL_Y
snippet K_CTRL_Y
	K_CTRL_Y -> { \${1://cuerpo...} }
# K_ALT_Y
snippet K_ALT_Y
	K_ALT_Y -> { \${1://cuerpo...} }
# K_SHIFT_Y
snippet K_SHIFT_Y
	K_SHIFT_Y -> { \${1://cuerpo...} }
# K_CTRL_ALT_Y
snippet K_CTRL_ALT_Y
	K_CTRL_ALT_Y -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_Y
snippet K_CTRL_SHIFT_Y
	K_CTRL_SHIFT_Y -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_Y
snippet K_CTRL_ALT_SHIFT_Y
	K_CTRL_ALT_SHIFT_Y -> { \${1://cuerpo...} }

# K_Z
snippet K_Z
	K_Z -> { \${1://cuerpo...} }
# K_CTRL_Z
snippet K_CTRL_Z
	K_CTRL_Z -> { \${1://cuerpo...} }
# K_ALT_Z
snippet K_ALT_Z
	K_ALT_Z -> { \${1://cuerpo...} }
# K_SHIFT_Z
snippet K_SHIFT_Z
	K_SHIFT_Z -> { \${1://cuerpo...} }
# K_CTRL_ALT_Z
snippet K_CTRL_ALT_Z
	K_CTRL_ALT_Z -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_Z
snippet K_CTRL_SHIFT_Z
	K_CTRL_SHIFT_Z -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_Z
snippet K_CTRL_ALT_SHIFT_Z
	K_CTRL_ALT_SHIFT_Z -> { \${1://cuerpo...} }

# K_0
snippet K_0
	K_0 -> { \${1://cuerpo...} }
# K_CTRL_0
snippet K_CTRL_0
	K_CTRL_0 -> { \${1://cuerpo...} }
# K_ALT_0
snippet K_ALT_0
	K_ALT_0 -> { \${1://cuerpo...} }
# K_SHIFT_0
snippet K_SHIFT_0
	K_SHIFT_0 -> { \${1://cuerpo...} }
# K_CTRL_ALT_0
snippet K_CTRL_ALT_0
	K_CTRL_ALT_0 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_0
snippet K_CTRL_SHIFT_0
	K_CTRL_SHIFT_0 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_0
snippet K_CTRL_ALT_SHIFT_0
	K_CTRL_ALT_SHIFT_0 -> { \${1://cuerpo...} }

# K_1
snippet K_1
	K_1 -> { \${1://cuerpo...} }
# K_CTRL_1
snippet K_CTRL_1
	K_CTRL_1 -> { \${1://cuerpo...} }
# K_ALT_1
snippet K_ALT_1
	K_ALT_1 -> { \${1://cuerpo...} }
# K_SHIFT_1
snippet K_SHIFT_1
	K_SHIFT_1 -> { \${1://cuerpo...} }
# K_CTRL_ALT_1
snippet K_CTRL_ALT_1
	K_CTRL_ALT_1 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_1
snippet K_CTRL_SHIFT_1
	K_CTRL_SHIFT_1 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_1
snippet K_CTRL_ALT_SHIFT_1
	K_CTRL_ALT_SHIFT_1 -> { \${1://cuerpo...} }

# K_2
snippet K_2
	K_2 -> { \${1://cuerpo...} }
# K_CTRL_2
snippet K_CTRL_2
	K_CTRL_2 -> { \${1://cuerpo...} }
# K_ALT_2
snippet K_ALT_2
	K_ALT_2 -> { \${1://cuerpo...} }
# K_SHIFT_2
snippet K_SHIFT_2
	K_SHIFT_2 -> { \${1://cuerpo...} }
# K_CTRL_ALT_2
snippet K_CTRL_ALT_2
	K_CTRL_ALT_2 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_2
snippet K_CTRL_SHIFT_2
	K_CTRL_SHIFT_2 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_2
snippet K_CTRL_ALT_SHIFT_2
	K_CTRL_ALT_SHIFT_2 -> { \${1://cuerpo...} }

# K_3
snippet K_3
	K_3 -> { \${1://cuerpo...} }
# K_CTRL_3
snippet K_CTRL_3
	K_CTRL_3 -> { \${1://cuerpo...} }
# K_ALT_3
snippet K_ALT_3
	K_ALT_3 -> { \${1://cuerpo...} }
# K_SHIFT_3
snippet K_SHIFT_3
	K_SHIFT_3 -> { \${1://cuerpo...} }
# K_CTRL_ALT_3
snippet K_CTRL_ALT_3
	K_CTRL_ALT_3 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_3
snippet K_CTRL_SHIFT_3
	K_CTRL_SHIFT_3 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_3
snippet K_CTRL_ALT_SHIFT_3
	K_CTRL_ALT_SHIFT_3 -> { \${1://cuerpo...} }

# K_4
snippet K_4
	K_4 -> { \${1://cuerpo...} }
# K_CTRL_4
snippet K_CTRL_4
	K_CTRL_4 -> { \${1://cuerpo...} }
# K_ALT_4
snippet K_ALT_4
	K_ALT_4 -> { \${1://cuerpo...} }
# K_SHIFT_4
snippet K_SHIFT_4
	K_SHIFT_4 -> { \${1://cuerpo...} }
# K_CTRL_ALT_4
snippet K_CTRL_ALT_4
	K_CTRL_ALT_4 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_4
snippet K_CTRL_SHIFT_4
	K_CTRL_SHIFT_4 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_4
snippet K_CTRL_ALT_SHIFT_4
	K_CTRL_ALT_SHIFT_4 -> { \${1://cuerpo...} }

# K_5
snippet K_5
	K_5 -> { \${1://cuerpo...} }
# K_CTRL_5
snippet K_CTRL_5
	K_CTRL_5 -> { \${1://cuerpo...} }
# K_ALT_5
snippet K_ALT_5
	K_ALT_5 -> { \${1://cuerpo...} }
# K_SHIFT_5
snippet K_SHIFT_5
	K_SHIFT_5 -> { \${1://cuerpo...} }
# K_CTRL_ALT_5
snippet K_CTRL_ALT_5
	K_CTRL_ALT_5 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_5
snippet K_CTRL_SHIFT_5
	K_CTRL_SHIFT_5 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_5
snippet K_CTRL_ALT_SHIFT_5
	K_CTRL_ALT_SHIFT_5 -> { \${1://cuerpo...} }

# K_6
snippet K_6
	K_6 -> { \${1://cuerpo...} }
# K_CTRL_6
snippet K_CTRL_6
	K_CTRL_6 -> { \${1://cuerpo...} }
# K_ALT_6
snippet K_ALT_6
	K_ALT_6 -> { \${1://cuerpo...} }
# K_SHIFT_6
snippet K_SHIFT_6
	K_SHIFT_6 -> { \${1://cuerpo...} }
# K_CTRL_ALT_6
snippet K_CTRL_ALT_6
	K_CTRL_ALT_6 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_6
snippet K_CTRL_SHIFT_6
	K_CTRL_SHIFT_6 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_6
snippet K_CTRL_ALT_SHIFT_6
	K_CTRL_ALT_SHIFT_6 -> { \${1://cuerpo...} }

# K_7
snippet K_7
	K_7 -> { \${1://cuerpo...} }
# K_CTRL_7
snippet K_CTRL_7
	K_CTRL_7 -> { \${1://cuerpo...} }
# K_ALT_7
snippet K_ALT_7
	K_ALT_7 -> { \${1://cuerpo...} }
# K_SHIFT_7
snippet K_SHIFT_7
	K_SHIFT_7 -> { \${1://cuerpo...} }
# K_CTRL_ALT_7
snippet K_CTRL_ALT_7
	K_CTRL_ALT_7 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_7
snippet K_CTRL_SHIFT_7
	K_CTRL_SHIFT_7 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_7
snippet K_CTRL_ALT_SHIFT_7
	K_CTRL_ALT_SHIFT_7 -> { \${1://cuerpo...} }

# K_8
snippet K_8
	K_8 -> { \${1://cuerpo...} }
# K_CTRL_8
snippet K_CTRL_8
	K_CTRL_8 -> { \${1://cuerpo...} }
# K_ALT_8
snippet K_ALT_8
	K_ALT_8 -> { \${1://cuerpo...} }
# K_SHIFT_8
snippet K_SHIFT_8
	K_SHIFT_8 -> { \${1://cuerpo...} }
# K_CTRL_ALT_8
snippet K_CTRL_ALT_8
	K_CTRL_ALT_8 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_8
snippet K_CTRL_SHIFT_8
	K_CTRL_SHIFT_8 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_8
snippet K_CTRL_ALT_SHIFT_8
	K_CTRL_ALT_SHIFT_8 -> { \${1://cuerpo...} }

# K_9
snippet K_9
	K_9 -> { \${1://cuerpo...} }
# K_CTRL_9
snippet K_CTRL_9
	K_CTRL_9 -> { \${1://cuerpo...} }
# K_ALT_9
snippet K_ALT_9
	K_ALT_9 -> { \${1://cuerpo...} }
# K_SHIFT_9
snippet K_SHIFT_9
	K_SHIFT_9 -> { \${1://cuerpo...} }
# K_CTRL_ALT_9
snippet K_CTRL_ALT_9
	K_CTRL_ALT_9 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_9
snippet K_CTRL_SHIFT_9
	K_CTRL_SHIFT_9 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_9
snippet K_CTRL_ALT_SHIFT_9
	K_CTRL_ALT_SHIFT_9 -> { \${1://cuerpo...} }

# K_F1
snippet K_F1
	K_F1 -> { \${1://cuerpo...} }
# K_CTRL_F1
snippet K_CTRL_F1
	K_CTRL_F1 -> { \${1://cuerpo...} }
# K_ALT_F1
snippet K_ALT_F1
	K_ALT_F1 -> { \${1://cuerpo...} }
# K_SHIFT_F1
snippet K_SHIFT_F1
	K_SHIFT_F1 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F1
snippet K_CTRL_ALT_F1
	K_CTRL_ALT_F1 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F1
snippet K_CTRL_SHIFT_F1
	K_CTRL_SHIFT_F1 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F1
snippet K_CTRL_ALT_SHIFT_F1
	K_CTRL_ALT_SHIFT_F1 -> { \${1://cuerpo...} }

# K_F2
snippet K_F2
	K_F2 -> { \${1://cuerpo...} }
# K_CTRL_F2
snippet K_CTRL_F2
	K_CTRL_F2 -> { \${1://cuerpo...} }
# K_ALT_F2
snippet K_ALT_F2
	K_ALT_F2 -> { \${1://cuerpo...} }
# K_SHIFT_F2
snippet K_SHIFT_F2
	K_SHIFT_F2 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F2
snippet K_CTRL_ALT_F2
	K_CTRL_ALT_F2 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F2
snippet K_CTRL_SHIFT_F2
	K_CTRL_SHIFT_F2 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F2
snippet K_CTRL_ALT_SHIFT_F2
	K_CTRL_ALT_SHIFT_F2 -> { \${1://cuerpo...} }

# K_F3
snippet K_F3
	K_F3 -> { \${1://cuerpo...} }
# K_CTRL_F3
snippet K_CTRL_F3
	K_CTRL_F3 -> { \${1://cuerpo...} }
# K_ALT_F3
snippet K_ALT_F3
	K_ALT_F3 -> { \${1://cuerpo...} }
# K_SHIFT_F3
snippet K_SHIFT_F3
	K_SHIFT_F3 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F3
snippet K_CTRL_ALT_F3
	K_CTRL_ALT_F3 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F3
snippet K_CTRL_SHIFT_F3
	K_CTRL_SHIFT_F3 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F3
snippet K_CTRL_ALT_SHIFT_F3
	K_CTRL_ALT_SHIFT_F3 -> { \${1://cuerpo...} }

# K_A
snippet K_A
	K_A -> { \${1://cuerpo...} }
# K_CTRL_A
snippet K_CTRL_A
	K_CTRL_A -> { \${1://cuerpo...} }
# K_ALT_A
snippet K_ALT_A
	K_ALT_A -> { \${1://cuerpo...} }
# K_SHIFT_A
snippet K_SHIFT_A
	K_SHIFT_A -> { \${1://cuerpo...} }
# K_CTRL_ALT_A
snippet K_CTRL_ALT_A
	K_CTRL_ALT_A -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_A
snippet K_CTRL_SHIFT_A
	K_CTRL_SHIFT_A -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_A
snippet K_CTRL_ALT_SHIFT_A
	K_CTRL_ALT_SHIFT_A -> { \${1://cuerpo...} }

# K_F5
snippet K_F5
	K_F5 -> { \${1://cuerpo...} }
# K_CTRL_F5
snippet K_CTRL_F5
	K_CTRL_F5 -> { \${1://cuerpo...} }
# K_ALT_F5
snippet K_ALT_F5
	K_ALT_F5 -> { \${1://cuerpo...} }
# K_SHIFT_F5
snippet K_SHIFT_F5
	K_SHIFT_F5 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F5
snippet K_CTRL_ALT_F5
	K_CTRL_ALT_F5 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F5
snippet K_CTRL_SHIFT_F5
	K_CTRL_SHIFT_F5 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F5
snippet K_CTRL_ALT_SHIFT_F5
	K_CTRL_ALT_SHIFT_F5 -> { \${1://cuerpo...} }

# K_F6
snippet K_F6
	K_F6 -> { \${1://cuerpo...} }
# K_CTRL_F6
snippet K_CTRL_F6
	K_CTRL_F6 -> { \${1://cuerpo...} }
# K_ALT_F6
snippet K_ALT_F6
	K_ALT_F6 -> { \${1://cuerpo...} }
# K_SHIFT_F6
snippet K_SHIFT_F6
	K_SHIFT_F6 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F6
snippet K_CTRL_ALT_F6
	K_CTRL_ALT_F6 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F6
snippet K_CTRL_SHIFT_F6
	K_CTRL_SHIFT_F6 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F6
snippet K_CTRL_ALT_SHIFT_F6
	K_CTRL_ALT_SHIFT_F6 -> { \${1://cuerpo...} }

# K_F7
snippet K_F7
	K_F7 -> { \${1://cuerpo...} }
# K_CTRL_F7
snippet K_CTRL_F7
	K_CTRL_F7 -> { \${1://cuerpo...} }
# K_ALT_F7
snippet K_ALT_F7
	K_ALT_F7 -> { \${1://cuerpo...} }
# K_SHIFT_F7
snippet K_SHIFT_F7
	K_SHIFT_F7 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F7
snippet K_CTRL_ALT_F7
	K_CTRL_ALT_F7 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F7
snippet K_CTRL_SHIFT_F7
	K_CTRL_SHIFT_F7 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F7
snippet K_CTRL_ALT_SHIFT_F7
	K_CTRL_ALT_SHIFT_F7 -> { \${1://cuerpo...} }

# K_F8
snippet K_F8
	K_F8 -> { \${1://cuerpo...} }
# K_CTRL_F8
snippet K_CTRL_F8
	K_CTRL_F8 -> { \${1://cuerpo...} }
# K_ALT_F8
snippet K_ALT_F8
	K_ALT_F8 -> { \${1://cuerpo...} }
# K_SHIFT_F8
snippet K_SHIFT_F8
	K_SHIFT_F8 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F8
snippet K_CTRL_ALT_F8
	K_CTRL_ALT_F8 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F8
snippet K_CTRL_SHIFT_F8
	K_CTRL_SHIFT_F8 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F8
snippet K_CTRL_ALT_SHIFT_F8
	K_CTRL_ALT_SHIFT_F8 -> { \${1://cuerpo...} }

# K_F9
snippet K_F9
	K_F9 -> { \${1://cuerpo...} }
# K_CTRL_F9
snippet K_CTRL_F9
	K_CTRL_F9 -> { \${1://cuerpo...} }
# K_ALT_F9
snippet K_ALT_F9
	K_ALT_F9 -> { \${1://cuerpo...} }
# K_SHIFT_F9
snippet K_SHIFT_F9
	K_SHIFT_F9 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F9
snippet K_CTRL_ALT_F9
	K_CTRL_ALT_F9 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F9
snippet K_CTRL_SHIFT_F9
	K_CTRL_SHIFT_F9 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F9
snippet K_CTRL_ALT_SHIFT_F9
	K_CTRL_ALT_SHIFT_F9 -> { \${1://cuerpo...} }

# K_F10
snippet K_F10
	K_F10 -> { \${1://cuerpo...} }
# K_CTRL_F10
snippet K_CTRL_F10
	K_CTRL_F10 -> { \${1://cuerpo...} }
# K_ALT_F10
snippet K_ALT_F10
	K_ALT_F10 -> { \${1://cuerpo...} }
# K_SHIFT_F10
snippet K_SHIFT_F10
	K_SHIFT_F10 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F10
snippet K_CTRL_ALT_F10
	K_CTRL_ALT_F10 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F10
snippet K_CTRL_SHIFT_F10
	K_CTRL_SHIFT_F10 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F10
snippet K_CTRL_ALT_SHIFT_F10
	K_CTRL_ALT_SHIFT_F10 -> { \${1://cuerpo...} }

# K_F11
snippet K_F11
	K_F11 -> { \${1://cuerpo...} }
# K_CTRL_F11
snippet K_CTRL_F11
	K_CTRL_F11 -> { \${1://cuerpo...} }
# K_ALT_F11
snippet K_ALT_F11
	K_ALT_F11 -> { \${1://cuerpo...} }
# K_SHIFT_F11
snippet K_SHIFT_F11
	K_SHIFT_F11 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F11
snippet K_CTRL_ALT_F11
	K_CTRL_ALT_F11 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F11
snippet K_CTRL_SHIFT_F11
	K_CTRL_SHIFT_F11 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F11
snippet K_CTRL_ALT_SHIFT_F11
	K_CTRL_ALT_SHIFT_F11 -> { \${1://cuerpo...} }

# K_F12
snippet K_F12
	K_F12 -> { \${1://cuerpo...} }
# K_CTRL_F12
snippet K_CTRL_F12
	K_CTRL_F12 -> { \${1://cuerpo...} }
# K_ALT_F12
snippet K_ALT_F12
	K_ALT_F12 -> { \${1://cuerpo...} }
# K_SHIFT_F12
snippet K_SHIFT_F12
	K_SHIFT_F12 -> { \${1://cuerpo...} }
# K_CTRL_ALT_F12
snippet K_CTRL_ALT_F12
	K_CTRL_ALT_F12 -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_F12
snippet K_CTRL_SHIFT_F12
	K_CTRL_SHIFT_F12 -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_F12
snippet K_CTRL_ALT_SHIFT_F12
	K_CTRL_ALT_SHIFT_F12 -> { \${1://cuerpo...} }

# K_RETURN
snippet K_RETURN
	K_RETURN -> { \${1://cuerpo...} }
# K_CTRL_RETURN
snippet K_CTRL_RETURN
	K_CTRL_RETURN -> { \${1://cuerpo...} }
# K_ALT_RETURN
snippet K_ALT_RETURN
	K_ALT_RETURN -> { \${1://cuerpo...} }
# K_SHIFT_RETURN
snippet K_SHIFT_RETURN
	K_SHIFT_RETURN -> { \${1://cuerpo...} }
# K_CTRL_ALT_RETURN
snippet K_CTRL_ALT_RETURN
	K_CTRL_ALT_RETURN -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_RETURN
snippet K_CTRL_SHIFT_RETURN
	K_CTRL_SHIFT_RETURN -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_RETURN
snippet K_CTRL_ALT_SHIFT_RETURN
	K_CTRL_ALT_SHIFT_RETURN -> { \${1://cuerpo...} }

# K_SPACE
snippet K_SPACE
	K_SPACE -> { \${1://cuerpo...} }
# K_CTRL_SPACE
snippet K_CTRL_SPACE
	K_CTRL_SPACE -> { \${1://cuerpo...} }
# K_ALT_SPACE
snippet K_ALT_SPACE
	K_ALT_SPACE -> { \${1://cuerpo...} }
# K_SHIFT_SPACE
snippet K_SHIFT_SPACE
	K_SHIFT_SPACE -> { \${1://cuerpo...} }
# K_CTRL_ALT_SPACE
snippet K_CTRL_ALT_SPACE
	K_CTRL_ALT_SPACE -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_SPACE
snippet K_CTRL_SHIFT_SPACE
	K_CTRL_SHIFT_SPACE -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_SPACE
snippet K_CTRL_ALT_SHIFT_SPACE
	K_CTRL_ALT_SHIFT_SPACE -> { \${1://cuerpo...} }

# K_ESCAPE
snippet K_ESCAPE
	K_ESCAPE -> { \${1://cuerpo...} }
# K_CTRL_ESCAPE
snippet K_CTRL_ESCAPE
	K_CTRL_ESCAPE -> { \${1://cuerpo...} }
# K_ALT_ESCAPE
snippet K_ALT_ESCAPE
	K_ALT_ESCAPE -> { \${1://cuerpo...} }
# K_SHIFT_ESCAPE
snippet K_SHIFT_ESCAPE
	K_SHIFT_ESCAPE -> { \${1://cuerpo...} }
# K_CTRL_ALT_ESCAPE
snippet K_CTRL_ALT_ESCAPE
	K_CTRL_ALT_ESCAPE -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_ESCAPE
snippet K_CTRL_SHIFT_ESCAPE
	K_CTRL_SHIFT_ESCAPE -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_ESCAPE
snippet K_CTRL_ALT_SHIFT_ESCAPE
	K_CTRL_ALT_SHIFT_ESCAPE -> { \${1://cuerpo...} }

# K_BACKSPACE
snippet K_BACKSPACE
	K_BACKSPACE -> { \${1://cuerpo...} }
# K_CTRL_BACKSPACE
snippet K_CTRL_BACKSPACE
	K_CTRL_BACKSPACE -> { \${1://cuerpo...} }
# K_ALT_BACKSPACE
snippet K_ALT_BACKSPACE
	K_ALT_BACKSPACE -> { \${1://cuerpo...} }
# K_SHIFT_BACKSPACE
snippet K_SHIFT_BACKSPACE
	K_SHIFT_BACKSPACE -> { \${1://cuerpo...} }
# K_CTRL_ALT_BACKSPACE
snippet K_CTRL_ALT_BACKSPACE
	K_CTRL_ALT_BACKSPACE -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_BACKSPACE
snippet K_CTRL_SHIFT_BACKSPACE
	K_CTRL_SHIFT_BACKSPACE -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_BACKSPACE
snippet K_CTRL_ALT_SHIFT_BACKSPACE
	K_CTRL_ALT_SHIFT_BACKSPACE -> { \${1://cuerpo...} }

# K_TAB
snippet K_TAB
	K_TAB -> { \${1://cuerpo...} }
# K_CTRL_TAB
snippet K_CTRL_TAB
	K_CTRL_TAB -> { \${1://cuerpo...} }
# K_ALT_TAB
snippet K_ALT_TAB
	K_ALT_TAB -> { \${1://cuerpo...} }
# K_SHIFT_TAB
snippet K_SHIFT_TAB
	K_SHIFT_TAB -> { \${1://cuerpo...} }
# K_CTRL_ALT_TAB
snippet K_CTRL_ALT_TAB
	K_CTRL_ALT_TAB -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_TAB
snippet K_CTRL_SHIFT_TAB
	K_CTRL_SHIFT_TAB -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_TAB
snippet K_CTRL_ALT_SHIFT_TAB
	K_CTRL_ALT_SHIFT_TAB -> { \${1://cuerpo...} }

# K_UP
snippet K_UP
	K_UP -> { \${1://cuerpo...} }
# K_CTRL_UP
snippet K_CTRL_UP
	K_CTRL_UP -> { \${1://cuerpo...} }
# K_ALT_UP
snippet K_ALT_UP
	K_ALT_UP -> { \${1://cuerpo...} }
# K_SHIFT_UP
snippet K_SHIFT_UP
	K_SHIFT_UP -> { \${1://cuerpo...} }
# K_CTRL_ALT_UP
snippet K_CTRL_ALT_UP
	K_CTRL_ALT_UP -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_UP
snippet K_CTRL_SHIFT_UP
	K_CTRL_SHIFT_UP -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_UP
snippet K_CTRL_ALT_SHIFT_UP
	K_CTRL_ALT_SHIFT_UP -> { \${1://cuerpo...} }

# K_DOWN
snippet K_DOWN
	K_DOWN -> { \${1://cuerpo...} }
# K_CTRL_DOWN
snippet K_CTRL_DOWN
	K_CTRL_DOWN -> { \${1://cuerpo...} }
# K_ALT_DOWN
snippet K_ALT_DOWN
	K_ALT_DOWN -> { \${1://cuerpo...} }
# K_SHIFT_DOWN
snippet K_SHIFT_DOWN
	K_SHIFT_DOWN -> { \${1://cuerpo...} }
# K_CTRL_ALT_DOWN
snippet K_CTRL_ALT_DOWN
	K_CTRL_ALT_DOWN -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_DOWN
snippet K_CTRL_SHIFT_DOWN
	K_CTRL_SHIFT_DOWN -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_DOWN
snippet K_CTRL_ALT_SHIFT_DOWN
	K_CTRL_ALT_SHIFT_DOWN -> { \${1://cuerpo...} }

# K_LEFT
snippet K_LEFT
	K_LEFT -> { \${1://cuerpo...} }
# K_CTRL_LEFT
snippet K_CTRL_LEFT
	K_CTRL_LEFT -> { \${1://cuerpo...} }
# K_ALT_LEFT
snippet K_ALT_LEFT
	K_ALT_LEFT -> { \${1://cuerpo...} }
# K_SHIFT_LEFT
snippet K_SHIFT_LEFT
	K_SHIFT_LEFT -> { \${1://cuerpo...} }
# K_CTRL_ALT_LEFT
snippet K_CTRL_ALT_LEFT
	K_CTRL_ALT_LEFT -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_LEFT
snippet K_CTRL_SHIFT_LEFT
	K_CTRL_SHIFT_LEFT -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_LEFT
snippet K_CTRL_ALT_SHIFT_LEFT
	K_CTRL_ALT_SHIFT_LEFT -> { \${1://cuerpo...} }

# K_RIGHT
snippet K_RIGHT
	K_RIGHT -> { \${1://cuerpo...} }
# K_CTRL_RIGHT
snippet K_CTRL_RIGHT
	K_CTRL_RIGHT -> { \${1://cuerpo...} }
# K_ALT_RIGHT
snippet K_ALT_RIGHT
	K_ALT_RIGHT -> { \${1://cuerpo...} }
# K_SHIFT_RIGHT
snippet K_SHIFT_RIGHT
	K_SHIFT_RIGHT -> { \${1://cuerpo...} }
# K_CTRL_ALT_RIGHT
snippet K_CTRL_ALT_RIGHT
	K_CTRL_ALT_RIGHT -> { \${1://cuerpo...} }
# K_CTRL_SHIFT_RIGHT
snippet K_CTRL_SHIFT_RIGHT
	K_CTRL_SHIFT_RIGHT -> { \${1://cuerpo...} }
# K_CTRL_ALT_SHIFT_RIGHT
snippet K_CTRL_ALT_SHIFT_RIGHT
	K_CTRL_ALT_SHIFT_RIGHT -> { \${1://cuerpo...} }

# recorrido (simple)
snippet recorrido (simple)
	\${1:// Ir al inicio}
	while (not \${2:// es último elemento}) {
		\${3:// Procesar el elemento}
		\${4:// Ir al próximo elemento}
	}
	\${5:// Finalizar}

# recorrido (de acumulación)
snippet recorrido (de acumulación)
	\${1:// Ir al inicio}
	\${2:cantidadVistos} := \${3:// contar elementos en lugar actual}
	while (not \${4:// es último elemento}) {
		\${4:// Ir al próximo elemento}
		\${2:cantidadVistos} := \${2:cantidadVistos} + \${3:// contar elementos en lugar actual}
	}
	return (\${2:cantidadVistos})

# recorrido (de búsqueda)
snippet recorrido (de búsqueda)
	\${1:// Ir al inicio}
	while (not \${2:// encontré lo que buscaba}) {
		\${3:// Ir al próximo elemento}
	}
	return (\${2:// encontré lo que buscaba })

# recorrido (de búsqueda con borde)
snippet recorrido (de búsqueda con borde)
	\${1:// Ir al inicio}
	while (not \${2:// encontré lo que buscaba} && not \${3:// es último elemento}) {
		\${4:// Ir al próximo elemento}
	}
	return (\${2:// encontré lo que buscaba })

# recorrido (de tipos enumerativos)
snippet recorrido (de tipos enumerativos)
	\${1:elementoActual} := \${2:minElemento()}
	while (\${1:elementoActual} /= \${3:maxElemento()}) {
		\${4:// Procesar con elemento actual}
		\${1:elementoActual} := siguiente(\${1:elementoActual})
	}
	\${4:// Procesar con elemento actual}

# recorrido (de búsqueda sobre lista)
snippet recorrido (de búsqueda sobre lista)
	\${1:listaRecorrida} := \${2:lista}
	while (primero(\${1:listaRecorrida}) /= \${3://elemento buscado}) {
		\${1:elementoActual} := sinElPrimero(\${1:elementoActual})
	}
	return (primero(\${1:listaRecorrida}))

# recorrido (de búsqueda sobre lista con borde)
snippet recorrido (de búsqueda sobre lista con borde)
	\${1:listaRecorrida} := \${2:lista}
	while (not esVacía(\${1:listaRecorrida}) && primero(\${1:listaRecorrida}) /= \${3://elemento buscado}) {
		\${1:elementoActual} := sinElPrimero(\${1:elementoActual})
	}
	return (not esVacía(\${1:listaRecorrida}))

# docs (procedimiento)
snippet docs (procedimiento)
	/*
		@PROPÓSITO: \${1:...}
		@PRECONDICIÓN: \${2:...}
	*/

# docs (procedimiento con parámetros)
snippet docs (procedimiento con parámetros)
	/*
		@PROPÓSITO: \${1:...}
		@PRECONDICIÓN: \${2:...}
		@PARÁMETROS:
				* \${3:nombreDelParámetro} : \${4:Tipo} - \${5:descripción}
	*/

# docs (función)
snippet docs (función)
	/*
		@PROPÓSITO: \${1:...}
		@PRECONDICIÓN: \${2:...}
		@TIPO: \${3:...}
	*/

# docs (función con parámetros)
snippet docs (función con parámetros)
	/*
		@PROPÓSITO: \${1:...}
		@PRECONDICIÓN: \${2:...}
		@PARÁMETROS:
				* \${3:nombreDelParámetro} : \${4:Tipo} - \${5:descripción}
		@TIPO: \${6:...}
	*/
`}),ace.define("ace/snippets/gobstones",["require","exports","module","ace/snippets/gobstones.snippets"],function(n,_,T){_.snippetText=n("./gobstones.snippets"),_.scope="gobstones"}),function(){ace.require(["ace/snippets/gobstones"],function(n){p&&(p.exports=n)})}()})(K);var L=K.exports;const C=o(L),i=F({__proto__:null,default:C},[L]);export{i as g};
