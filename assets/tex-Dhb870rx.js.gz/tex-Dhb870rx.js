import{g as $}from"./_commonjsHelpers-Cpj98o6Y.js";function c(i,p){for(var t=0;t<p.length;t++){const n=p[t];if(typeof n!="string"&&!Array.isArray(n)){for(const e in n)if(e!=="default"&&!(e in i)){const s=Object.getOwnPropertyDescriptor(n,e);s&&Object.defineProperty(i,e,s.get?s:{enumerable:!0,get:()=>n[e]})}}}return Object.freeze(Object.defineProperty(i,Symbol.toStringTag,{value:"Module"}))}var a={exports:{}};(function(i,p){ace.define("ace/snippets/tex.snippets",["require","exports","module"],function(t,n,e){e.exports=`#PREAMBLE
#newcommand
snippet nc
	\\newcommand{\\\${1:cmd}}[\${2:opt}]{\${3:realcmd}}\${4}
#usepackage
snippet up
	\\usepackage[\${1:[options}]{\${2:package}}
#newunicodechar
snippet nuc
	\\newunicodechar{\${1}}{\${2:\\ensuremath}\${3:tex-substitute}}}
#DeclareMathOperator
snippet dmo
	\\DeclareMathOperator{\${1}}{\${2}}

#DOCUMENT
# \\begin{}...\\end{}
snippet begin
	\\begin{\${1:env}}
		\${2}
	\\end{$1}
# Tabular
snippet tab
	\\begin{\${1:tabular}}{\${2:c}}
	\${3}
	\\end{$1}
snippet thm
	\\begin[\${1:author}]{\${2:thm}}
	\${3}
	\\end{$1}
snippet center
	\\begin{center}
		\${1}
	\\end{center}
# Align(ed)
snippet ali
	\\begin{align\${1:ed}}
		\${2}
	\\end{align$1}
# Gather(ed)
snippet gat
	\\begin{gather\${1:ed}}
		\${2}
	\\end{gather$1}
# Equation
snippet eq
	\\begin{equation}
		\${1}
	\\end{equation}
# Equation
snippet eq*
	\\begin{equation*}
		\${1}
	\\end{equation*}
# Unnumbered Equation
snippet \\
	\\[
		\${1}
	\\]
# Enumerate
snippet enum
	\\begin{enumerate}
		\\item \${1}
	\\end{enumerate}
# Itemize
snippet itemize
	\\begin{itemize}
		\\item \${1}
	\\end{itemize}
# Description
snippet desc
	\\begin{description}
		\\item[\${1}] \${2}
	\\end{description}
# Matrix
snippet mat
	\\begin{\${1:p/b/v/V/B/small}matrix}
		\${2}
	\\end{$1matrix}
# Cases
snippet cas
	\\begin{cases}
		\${1:equation}, &\\text{ if }\${2:case}\\\\
		\${3}
	\\end{cases}
# Split
snippet spl
	\\begin{split}
		\${1}
	\\end{split}
# Part
snippet part
	\\part{\${1:part name}} % (fold)
	\\label{prt:\${2:$1}}
	\${3}
	% part $2 (end)
# Chapter
snippet cha
	\\chapter{\${1:chapter name}}
	\\label{cha:\${2:$1}}
	\${3}
# Section
snippet sec
	\\section{\${1:section name}}
	\\label{sec:\${2:$1}}
	\${3}
# Sub Section
snippet sub
	\\subsection{\${1:subsection name}}
	\\label{sub:\${2:$1}}
	\${3}
# Sub Sub Section
snippet subs
	\\subsubsection{\${1:subsubsection name}}
	\\label{ssub:\${2:$1}}
	\${3}
# Paragraph
snippet par
	\\paragraph{\${1:paragraph name}}
	\\label{par:\${2:$1}}
	\${3}
# Sub Paragraph
snippet subp
	\\subparagraph{\${1:subparagraph name}}
	\\label{subp:\${2:$1}}
	\${3}
#References
snippet itd
	\\item[\${1:description}] \${2:item}
snippet figure
	\${1:Figure}~\\ref{\${2:fig:}}\${3}
snippet table
	\${1:Table}~\\ref{\${2:tab:}}\${3}
snippet listing
	\${1:Listing}~\\ref{\${2:list}}\${3}
snippet section
	\${1:Section}~\\ref{\${2:sec:}}\${3}
snippet page
	\${1:page}~\\pageref{\${2}}\${3}
snippet index
	\\index{\${1:index}}\${2}
#Citations
snippet cite
	\\cite[\${1}]{\${2}}\${3}
snippet fcite
	\\footcite[\${1}]{\${2}}\${3}
#Formating text: italic, bold, underline, small capital, emphase ..
snippet it
	\\textit{\${1:text}}
snippet bf
	\\textbf{\${1:text}}
snippet under
	\\underline{\${1:text}}
snippet emp
	\\emph{\${1:text}}
snippet sc
	\\textsc{\${1:text}}
#Choosing font
snippet sf
	\\textsf{\${1:text}}
snippet rm
	\\textrm{\${1:text}}
snippet tt
	\\texttt{\${1:text}}
#misc
snippet ft
	\\footnote{\${1:text}}
snippet fig
	\\begin{figure}
	\\begin{center}
	    \\includegraphics[scale=\${1}]{Figures/\${2}}
	\\end{center}
	\\caption{\${3}}
	\\label{fig:\${4}}
	\\end{figure}
snippet tikz
	\\begin{figure}
	\\begin{center}
	\\begin{tikzpicture}[scale=\${1:1}]
		\${2}
	\\end{tikzpicture}
	\\end{center}
	\\caption{\${3}}
	\\label{fig:\${4}}
	\\end{figure}
#math
snippet stackrel
	\\stackrel{\${1:above}}{\${2:below}} \${3}
snippet frac
	\\frac{\${1:num}}{\${2:denom}}
snippet sum
	\\sum^{\${1:n}}_{\${2:i=1}}{\${3}}`}),ace.define("ace/snippets/tex",["require","exports","module","ace/snippets/tex.snippets"],function(t,n,e){n.snippetText=t("./tex.snippets"),n.scope="tex"}),function(){ace.require(["ace/snippets/tex"],function(t){i&&(i.exports=t)})}()})(a);var r=a.exports;const o=$(r),b=c({__proto__:null,default:o},[r]);export{b as t};
