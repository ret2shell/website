import{g as c}from"./_commonjsHelpers-Cpj98o6Y.js";function o(i,s){for(var n=0;n<s.length;n++){const t=s[n];if(typeof t!="string"&&!Array.isArray(t)){for(const e in t)if(e!=="default"&&!(e in i)){const a=Object.getOwnPropertyDescriptor(t,e);a&&Object.defineProperty(i,e,a.get?a:{enumerable:!0,get:()=>t[e]})}}}return Object.freeze(Object.defineProperty(i,Symbol.toStringTag,{value:"Module"}))}var r={exports:{}};(function(i,s){ace.define("ace/snippets/actionscript.snippets",["require","exports","module"],function(n,t,e){e.exports=`snippet main
	package {
		import flash.display.*;
		import flash.Events.*;
	
		public class Main extends Sprite {
			public function Main (	) {
				trace("start");
				stage.scaleMode = StageScaleMode.NO_SCALE;
				stage.addEventListener(Event.RESIZE, resizeListener);
			}
	
			private function resizeListener (e:Event):void {
				trace("The application window changed size!");
				trace("New width:  " + stage.stageWidth);
				trace("New height: " + stage.stageHeight);
			}
	
		}
	
	}
snippet class
	\${1:public|internal} class \${2:name} \${3:extends } {
		public function $2 (	) {
			("start");
		}
	}
snippet all
	package name {

		\${1:public|internal|final} class \${2:name} \${3:extends } {
			private|public| static const FOO = "abc";
			private|public| static var BAR = "abc";

			// class initializer - no JIT !! one time setup
			if Cababilities.os == "Linux|MacOS" {
				FOO = "other";
			}

			// constructor:
			public function $2 (	){
				super2();
				trace("start");
			}
			public function name (a, b...){
				super.name(..);
				lable:break
			}
		}
	}

	function A(){
		// A can only be accessed within this file
	}
snippet switch
	switch(\${1}){
		case \${2}:
			\${3}
		break;
		default:
	}
snippet case
		case \${1}:
			\${2}
		break;
snippet package
	package \${1:package}{
		\${2}
	}
snippet wh
	while \${1:cond}{
		\${2}
	}
snippet do
	do {
		\${2}
	} while (\${1:cond})
snippet while
	while \${1:cond}{
		\${2}
	}
snippet for enumerate names
	for (\${1:var} in \${2:object}){
		\${3}
	}
snippet for enumerate values
	for each (\${1:var} in \${2:object}){
		\${3}
	}
snippet get_set
	function get \${1:name} {
		return \${2}
	}
	function set $1 (newValue) {
		\${3}
	}
snippet interface
	interface name {
		function method(\${1}):\${2:returntype};
	}
snippet try
	try {
		\${1}
	} catch (error:ErrorType) {
		\${2}
	} finally {
		\${3}
	}
# For Loop (same as c.snippet)
snippet for for (..) {..}
	for (\${2:i} = 0; $2 < \${1:count}; $2\${3:++}) {
		\${4:/* code */}
	}
# Custom For Loop
snippet forr
	for (\${1:i} = \${2:0}; \${3:$1 < 10}; $1\${4:++}) {
		\${5:/* code */}
	}
# If Condition
snippet if
	if (\${1:/* condition */}) {
		\${2:/* code */}
	}
snippet el
	else {
		\${1}
	}
# Ternary conditional
snippet t
	\${1:/* condition */} ? \${2:a} : \${3:b}
snippet fun
	function \${1:function_name}(\${2})\${3}
	{
		\${4:/* code */}
	}
# FlxSprite (usefull when using the flixel library)
snippet FlxSprite
	package
	{
		import org.flixel.*

		public class \${1:ClassName} extends \${2:FlxSprite}
		{
			public function $1(\${3: X:Number, Y:Number}):void
			{
				super(X,Y);
				\${4: //code...}
			}

			override public function update():void
			{
				super.update();
				\${5: //code...}
			}
		}
	}

`}),ace.define("ace/snippets/actionscript",["require","exports","module","ace/snippets/actionscript.snippets"],function(n,t,e){t.snippetText=n("./actionscript.snippets"),t.scope="actionscript"}),function(){ace.require(["ace/snippets/actionscript"],function(n){i&&(i.exports=n)})}()})(r);var p=r.exports;const l=c(p),$=o({__proto__:null,default:l},[p]);export{$ as a};
